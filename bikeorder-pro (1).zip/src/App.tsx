/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bike, 
  Store, 
  MessageCircle, 
  MapPin, 
  Calendar, 
  Palette, 
  DollarSign, 
  Hash, 
  StickyNote, 
  Send,
  CheckCircle2,
  ChevronRight,
  Plus,
  Minus,
  Trash2
} from 'lucide-react';

interface OrderData {
  shopName: string;
  waNumber: string;
  address: string;
  date: string;
  bikeType: string;
  color: string;
  price: number;
  qty: number;
  note: string;
}

const BIKE_TYPES = [
  'Mountain Bike (MTB)',
  'Road Bike',
  'Folding Bike (Seli)',
  'BMX',
  'Hybrid Bike',
  'Electric Bike (E-Bike)',
  'Gravel Bike',
  'City Bike'
];

const COLORS = [
  { name: 'Matte Black', class: 'bg-zinc-900' },
  { name: 'Pearl White', class: 'bg-white border border-zinc-200' },
  { name: 'Racing Red', class: 'bg-red-600' },
  { name: 'Sky Blue', class: 'bg-sky-500' },
  { name: 'Forest Green', class: 'bg-emerald-700' },
  { name: 'Solar Yellow', class: 'bg-yellow-400' },
  { name: 'Titanium Grey', class: 'bg-slate-500' },
  { name: 'Electric Orange', class: 'bg-orange-500' }
];

export default function App() {
  const [order, setOrder] = useState<OrderData>({
    shopName: '',
    waNumber: '',
    address: '',
    date: new Date().toISOString().split('T')[0],
    bikeType: BIKE_TYPES[0],
    color: COLORS[0].name,
    price: 0,
    qty: 1,
    note: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setOrder(prev => ({
      ...prev,
      [name]: name === 'price' || name === 'qty' ? Number(value) : value
    }));
  };

  const adjustQty = (amount: number) => {
    setOrder(prev => ({
      ...prev,
      qty: Math.max(1, prev.qty + amount)
    }));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const sendToWhatsApp = () => {
    const message = `*ORDER SEPEDA BARU*%0A%0A` +
      `*Toko:* ${order.shopName}%0A` +
      `*Tanggal:* ${order.date}%0A` +
      `*Alamat:* ${order.address}%0A%0A` +
      `*Detail Pesanan:*%0A` +
      `- Jenis: ${order.bikeType}%0A` +
      `- Warna: ${order.color}%0A` +
      `- Harga: ${formatCurrency(order.price)}%0A` +
      `- Qty: ${order.qty}%0A` +
      `- Total: ${formatCurrency(order.price * order.qty)}%0A%0A` +
      `*Catatan:* ${order.note || '-'}%0A%0A` +
      `_Dikirim via BikeOrder Pro_`;

    const cleanWANumber = order.waNumber.replace(/[^0-9]/g, '');
    const finalWA = cleanWANumber.startsWith('0') ? '62' + cleanWANumber.slice(1) : cleanWANumber;
    
    window.open(`https://wa.me/${finalWA}?text=${message}`, '_blank');
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans selection:bg-zinc-900 selection:text-white">
      {/* Background Pattern */}
      <div className="fixed inset-0 z-0 opacity-[0.03] pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 py-12 md:py-20">
        {/* Header */}
        <header className="mb-12 text-center md:text-left">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 text-white text-xs font-medium mb-4"
          >
            <Bike size={14} />
            <span>BIKEORDER PRO v1.0</span>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold tracking-tight mb-4"
          >
            Sistem Order <span className="text-zinc-500">Sepeda.</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-zinc-500 text-lg max-w-2xl"
          >
            Kelola pesanan toko sepeda Anda dengan mudah dan kirim langsung ke pelanggan via WhatsApp.
          </motion.p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Form Section */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="bg-white rounded-3xl border border-zinc-200 p-6 md:p-8 shadow-sm">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Store size={20} className="text-zinc-400" />
                Informasi Toko & Pelanggan
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600 ml-1">Nama Toko</label>
                  <div className="relative">
                    <Store className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                    <input 
                      type="text" 
                      name="shopName"
                      value={order.shopName}
                      onChange={handleInputChange}
                      placeholder="Contoh: Maju Jaya Bike"
                      className="w-full pl-10 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600 ml-1">Nomer WhatsApp</label>
                  <div className="relative">
                    <MessageCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                    <input 
                      type="tel" 
                      name="waNumber"
                      value={order.waNumber}
                      onChange={handleInputChange}
                      placeholder="08123456789"
                      className="w-full pl-10 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <label className="text-sm font-medium text-zinc-600 ml-1">Alamat Lengkap</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 text-zinc-400" size={18} />
                  <textarea 
                    name="address"
                    value={order.address}
                    onChange={handleInputChange}
                    placeholder="Masukkan alamat pengiriman..."
                    rows={3}
                    className="w-full pl-10 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all resize-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-600 ml-1">Tanggal Order</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                  <input 
                    type="date" 
                    name="date"
                    value={order.date}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-zinc-200 p-6 md:p-8 shadow-sm">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Bike size={20} className="text-zinc-400" />
                Detail Sepeda
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600 ml-1">Jenis Sepeda</label>
                  <select 
                    name="bikeType"
                    value={order.bikeType}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all appearance-none cursor-pointer"
                  >
                    {BIKE_TYPES.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600 ml-1">Pilih Warna</label>
                  <div className="flex flex-wrap gap-2">
                    {COLORS.map(color => (
                      <button
                        key={color.name}
                        onClick={() => setOrder(prev => ({ ...prev, color: color.name }))}
                        className={`w-8 h-8 rounded-full ${color.class} transition-all ${order.color === color.name ? 'ring-2 ring-offset-2 ring-zinc-900 scale-110' : 'hover:scale-110'}`}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600 ml-1">Harga Satuan (Rp)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                    <input 
                      type="number" 
                      name="price"
                      value={order.price || ''}
                      onChange={handleInputChange}
                      placeholder="0"
                      className="w-full pl-10 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-600 ml-1">Kuantitas (Qty)</label>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => adjustQty(-1)}
                      className="p-3 bg-zinc-100 hover:bg-zinc-200 rounded-xl transition-colors"
                    >
                      <Minus size={18} />
                    </button>
                    <div className="flex-1 text-center py-3 bg-zinc-50 border border-zinc-200 rounded-xl font-bold">
                      {order.qty}
                    </div>
                    <button 
                      onClick={() => adjustQty(1)}
                      className="p-3 bg-zinc-100 hover:bg-zinc-200 rounded-xl transition-colors"
                    >
                      <Plus size={18} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-600 ml-1">Catatan Tambahan</label>
                <div className="relative">
                  <StickyNote className="absolute left-3 top-3 text-zinc-400" size={18} />
                  <textarea 
                    name="note"
                    value={order.note}
                    onChange={handleInputChange}
                    placeholder="Contoh: Bonus helm, setting rem depan..."
                    rows={3}
                    className="w-full pl-10 pr-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/5 focus:border-zinc-900 transition-all resize-none"
                  />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Summary Section */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-5"
          >
            <div className="sticky top-8 space-y-6">
              <div className="bg-zinc-900 text-white rounded-3xl p-8 shadow-xl overflow-hidden relative">
                {/* Decorative Circle */}
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
                
                <h2 className="text-xl font-bold mb-8 flex items-center justify-between">
                  Ringkasan Order
                  <span className="text-xs font-normal opacity-50 uppercase tracking-widest">Preview</span>
                </h2>

                <div className="space-y-6 relative z-10">
                  <div className="flex justify-between items-start border-b border-white/10 pb-4">
                    <div>
                      <p className="text-xs text-white/50 uppercase tracking-wider mb-1">Produk</p>
                      <p className="font-medium">{order.bikeType}</p>
                      <p className="text-sm text-white/70">{order.color}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-white/50 uppercase tracking-wider mb-1">Qty</p>
                      <p className="font-medium">x{order.qty}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-white/50">Harga Satuan</span>
                      <span>{formatCurrency(order.price)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-white/50">Subtotal</span>
                      <span>{formatCurrency(order.price * order.qty)}</span>
                    </div>
                    <div className="flex justify-between items-center pt-4 border-t border-white/10">
                      <span className="text-lg font-bold">Total Bayar</span>
                      <span className="text-2xl font-bold text-emerald-400">
                        {formatCurrency(order.price * order.qty)}
                      </span>
                    </div>
                  </div>

                  <div className="pt-4">
                    <p className="text-xs text-white/50 uppercase tracking-wider mb-2">Dikirim Ke</p>
                    <p className="text-sm leading-relaxed text-white/80 italic">
                      {order.address || "Alamat belum diisi..."}
                    </p>
                  </div>

                  <button 
                    onClick={sendToWhatsApp}
                    disabled={!order.shopName || !order.waNumber}
                    className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all ${
                      !order.shopName || !order.waNumber 
                        ? 'bg-white/10 text-white/30 cursor-not-allowed' 
                        : 'bg-emerald-500 hover:bg-emerald-400 text-white active:scale-95'
                    }`}
                  >
                    {isSubmitted ? (
                      <>
                        <CheckCircle2 size={20} />
                        Berhasil Terkirim
                      </>
                    ) : (
                      <>
                        <Send size={20} />
                        Kirim ke WhatsApp
                      </>
                    )}
                  </button>
                  
                  <p className="text-[10px] text-center text-white/30 uppercase tracking-widest">
                    Pastikan nomer WA sudah benar
                  </p>
                </div>
              </div>

              {/* Quick Tips */}
              <div className="bg-white rounded-3xl border border-zinc-200 p-6">
                <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-400 mb-4">Tips Cepat</h3>
                <ul className="space-y-3">
                  <li className="flex gap-3 text-sm text-zinc-600">
                    <div className="w-5 h-5 rounded-full bg-zinc-100 flex items-center justify-center flex-shrink-0 text-[10px] font-bold">1</div>
                    Gunakan format internasional (62) untuk WA jika perlu.
                  </li>
                  <li className="flex gap-3 text-sm text-zinc-600">
                    <div className="w-5 h-5 rounded-full bg-zinc-100 flex items-center justify-center flex-shrink-0 text-[10px] font-bold">2</div>
                    Tambahkan catatan khusus untuk permintaan rakitan.
                  </li>
                </ul>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Footer */}
        <footer className="mt-20 pt-8 border-t border-zinc-200 text-center text-zinc-400 text-sm">
          <p>&copy; 2026 BikeOrder Pro. Designed for modern bike shops.</p>
        </footer>
      </div>

      {/* Success Toast */}
      <AnimatePresence>
        {isSubmitted && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 bg-zinc-900 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3"
          >
            <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center">
              <CheckCircle2 size={14} />
            </div>
            <span className="font-medium">Membuka WhatsApp...</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
